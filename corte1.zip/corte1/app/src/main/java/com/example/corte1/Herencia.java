package com.example.corte1;public class Herencia
{
    public static void main(String[] args)
    {

    }
}
